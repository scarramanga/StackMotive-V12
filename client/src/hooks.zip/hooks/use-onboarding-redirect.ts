import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/context/auth-context';

const EXCLUDED_PATHS = ['/onboarding', '/login', '/register'];

export function useOnboardingRedirect() {
  const [location, navigate] = useLocation();
  const { user, hasCompletedOnboarding } = useAuth();

  useEffect(() => {
    if (!user || EXCLUDED_PATHS.includes(location)) {
      return;
    }

    // Force redirect to onboarding for users who haven't completed it
    if (!hasCompletedOnboarding) {
      console.log('🔄 useOnboardingRedirect: Redirecting to onboarding');
      navigate('/onboarding');
    }
  }, [user, hasCompletedOnboarding, location, navigate]);
} 