import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export interface PaperTradingAccount {
  id: number;
  userId: string;
  name: string;
  initialBalance: number;
  currentBalance: number;
  currency: string;
  isActive: boolean;
  strategyName?: string;
  lastStrategyRunAt?: string;
  createdAt: Date;
  updatedAt: Date;
  // Enhanced portfolio valuation fields
  cashBalance: number;
  totalHoldingsValue: number;
  totalPortfolioValue: number;
  totalProfitLoss: number;
  totalProfitLossPercent: number;
}

export function usePaperTradingAccount() {
  return useQuery({
    queryKey: ['paper-trading-account'],
    queryFn: async () => {
      try {
        // apiRequest already handles response parsing and 404 cases
        const data = await apiRequest('GET', '/api/user/paper-trading-account');
        
        // Return null if no data (404 case is handled by apiRequest)
        if (!data) {
          return null;
        }
        
        return {
          ...data,
          createdAt: new Date(data.createdAt),
          updatedAt: new Date(data.updatedAt)
        } as PaperTradingAccount;
      } catch (error: any) {
        // 404 means no account exists, which is valid - return null instead of throwing
        if (error?.status === 404) {
          console.log('No paper trading account found (404) - returning null');
          return null;
        }
        
        console.error('Paper trading account fetch error:', error);
        throw error;
      }
    },
    staleTime: 0, // Match auth context - no caching
    refetchOnMount: true, // Match auth context
    retry: false, // Don't retry on failure
    refetchOnWindowFocus: false, // Prevent refetching on window focus
    refetchInterval: false // Disable periodic refetching
  });
} 