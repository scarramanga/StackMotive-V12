import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { usePaperTradingAccount } from '@/hooks/use-paper-trading';

export interface Holding {
  symbol: string;
  exchange: string;
  broker: string;
  quantity: number;
  averagePrice: number;
  totalValue: number;
  currentPrice: number;
  value: number;
  change: number;
  changePercent: number;
  allocation: number;
  type: 'equity' | 'crypto';
  profitLoss: number;
  profitLossPercent: number;
  trades: {
    id: number;
    entryPrice: number;
    amount: number;
    entryTime: string;
    strategy?: string;
  }[];
}

export function useHoldings() {
  const { data: paperTradingAccount } = usePaperTradingAccount();
  
  return useQuery({
    queryKey: ['holdings', 'paper-trading', paperTradingAccount?.id],
    queryFn: async () => {
      if (!paperTradingAccount?.id) {
        return [];
      }
      
      // Fetch trades from paper trading account
      const tradesResponse = await apiRequest('GET', `/api/user/paper-trading-account/${paperTradingAccount.id}/trades`);
      const trades = tradesResponse || [];
      
      // Filter only executed trades
      const executedTrades = trades.filter((trade: any) => trade.status === 'executed');
      
      if (!executedTrades.length) {
        return [];
      }
      
      // Group trades by symbol and calculate holdings
      const holdingsMap = new Map();
      
      for (const trade of executedTrades) {
        const symbol = trade.symbol;
        
        if (!holdingsMap.has(symbol)) {
          holdingsMap.set(symbol, {
            symbol,
            exchange: 'NASDAQ', // Default exchange
            broker: 'Paper Trading',
            quantity: 0,
            totalCost: 0,
            trades: []
          });
        }
        
        const holding = holdingsMap.get(symbol);
        const quantity = trade.quantity || 1;
        const price = trade.price || trade.executionPrice || 0;
        
        holding.quantity += quantity;
        holding.totalCost += quantity * price;
        holding.trades.push({
          id: trade.id,
          entryPrice: price,
          amount: quantity,
          entryTime: trade.createdAt || trade.timestamp,
          strategy: trade.strategy || 'Manual'
        });
      }
      
      // Convert to holdings array and fetch current prices
      const holdings: Holding[] = [];
      
      for (const [symbol, holding] of Array.from(holdingsMap.entries())) {
        const averagePrice = holding.totalCost / holding.quantity;
        
        // Fetch current price for this symbol
        let currentPrice = averagePrice; // Fallback to average price
        try {
          const priceResponse = await apiRequest('GET', `/api/market/price/${symbol}`);
          currentPrice = priceResponse?.price || averagePrice;
        } catch (error) {
          console.warn(`Failed to fetch current price for ${symbol}:`, error);
        }
        
        const currentValue = holding.quantity * currentPrice;
        const profitLoss = currentValue - holding.totalCost;
        const profitLossPercent = (profitLoss / holding.totalCost) * 100;
        const change = currentPrice - averagePrice;
        const changePercent = (change / averagePrice) * 100;
        
        holdings.push({
          symbol,
          exchange: holding.exchange,
          broker: holding.broker,
          quantity: holding.quantity,
          averagePrice,
          totalValue: holding.totalCost,
          currentPrice,
          value: currentValue,
          change,
          changePercent,
          allocation: 0, // Will be calculated based on total portfolio value
          type: symbol.includes('BTC') || symbol.includes('ETH') ? 'crypto' : 'equity',
          profitLoss,
          profitLossPercent,
          trades: holding.trades
        });
      }
      
      // Calculate allocations
      const totalPortfolioValue = holdings.reduce((sum, h) => sum + h.value, 0);
      holdings.forEach(holding => {
        holding.allocation = totalPortfolioValue > 0 ? (holding.value / totalPortfolioValue) * 100 : 0;
      });
      
      return holdings;
    },
    enabled: !!paperTradingAccount?.id,
    staleTime: 30000, // 30 seconds
    refetchInterval: 30000, // Refetch every 30 seconds
  });
} 